"""
============================================================================
 Experiment Configuration and Analysis
 SLAM Technology Final Project -- 2335053620, Yifan Tang
 Six-configuration ablation matrix for Scaffold-GS improvements.
============================================================================
"""

import json
import os
from dataclasses import dataclass, field
from typing import List, Dict, Tuple, Optional
import numpy as np


@dataclass
class ExperimentConfig:
    """Configuration for a single experiment run."""
    name: str
    description: str
    # Model params
    feat_dim: int = 32
    n_offsets: int = 10
    voxel_size: float = 0.001
    update_depth: int = 3
    update_init_factor: int = 16
    update_hierachy_factor: int = 4
    # Improvement flags
    use_eaad: bool = False     # Error-Guided Adaptive Anchor Densification
    use_casef: bool = False    # Cross-Attention Shared Encoder Fusion
    # EAAD params
    error_threshold: float = 0.1
    densify_interval: int = 500
    start_densify: int = 2000
    end_densify: int = 12000
    max_new_anchors_per_iter: int = 500
    feature_init_mode: str = "nearest"
    # CASEF params
    d_model: int = 128
    n_heads: int = 4
    encoder_layers: int = 3
    # Training
    iterations: int = 30000
    lr_position: float = 0.0
    lr_offset: float = 0.01
    lambda_dssim: float = 0.2
    # Data
    source_path: str = ""
    model_path: str = ""
    white_background: bool = False
    eval: bool = False
    # Seed
    seed: int = 42


@dataclass
class ExperimentResult:
    """Container for experiment results."""
    config: ExperimentConfig
    psnr: float = 0.0
    ssim: float = 0.0
    lpips: float = 0.0
    train_time_hours: float = 0.0
    peak_gpu_memory_gb: float = 0.0
    inference_fps: float = 0.0
    num_anchors_final: int = 0
    num_neural_gaussians: int = 0
    model_size_mb: float = 0.0
    per_view_psnr: Dict[str, float] = field(default_factory=dict)
    per_view_ssim: Dict[str, float] = field(default_factory=dict)
    error_log: List[str] = field(default_factory=list)
    success: bool = False


# ============================================================================
# Experiment Matrix Definition
# ============================================================================

def get_experiment_matrix() -> List[ExperimentConfig]:
    """
    Define the full experiment matrix for ablation study.
    
    Returns 6 configurations:
    - C0: Baseline
    - C1: EAAD only
    - C2: CASEF only
    - C3: Combined (EAAD + CASEF)
    - C4: EAAD ablation (no feature interpolation)
    - C5: CASEF ablation (no cross-attention)
    """
    experiments = []
    
    # C0: Baseline
    experiments.append(ExperimentConfig(
        name="C0_Baseline",
        description="Original Scaffold-GS without modifications",
    ))
    
    # C1: EAAD only
    experiments.append(ExperimentConfig(
        name="C1_EAAD",
        description="Improvement 1: Error-Guided Adaptive Anchor Densification",
        use_eaad=True,
    ))
    
    # C2: CASEF only
    experiments.append(ExperimentConfig(
        name="C2_CASEF",
        description="Improvement 2: Cross-Attention Shared Encoder Fusion",
        use_casef=True,
    ))
    
    # C3: Combined
    experiments.append(ExperimentConfig(
        name="C3_Combined",
        description="Both improvements applied together",
        use_eaad=True,
        use_casef=True,
    ))
    
    # C4: EAAD Ablation (zero-init features)
    experiments.append(ExperimentConfig(
        name="C4_EAAD_Ablation",
        description="EAAD with zero feature initialization (ablation)",
        use_eaad=True,
        feature_init_mode="zero",
    ))
    
    # C5: CASEF Ablation (no cross-attention)
    experiments.append(ExperimentConfig(
        name="C5_CASEF_Ablation",
        description="CASEF with shared encoder only, no cross-attention (ablation)",
        use_casef=True,
        n_heads=0,  # Disable cross-attention
    ))
    
    return experiments


# ============================================================================
# Results Analysis
# ============================================================================

def compare_results(results: List[ExperimentResult]) -> Dict:
    """
    Compare results across configurations and compute delta metrics.
    """
    baseline = next((r for r in results if r.config.name == "C0_Baseline"), None)
    if baseline is None:
        return {"error": "No baseline results found"}
    
    comparison = {
        "baseline": {
            "psnr": baseline.psnr,
            "ssim": baseline.ssim,
            "lpips": baseline.lpips,
            "fps": baseline.inference_fps,
            "train_time": baseline.train_time_hours,
            "gpu_mem": baseline.peak_gpu_memory_gb,
        },
        "deltas": {}
    }
    
    for r in results:
        if r.config.name == "C0_Baseline":
            continue
        comparison["deltas"][r.config.name] = {
            "psnr_delta": r.psnr - baseline.psnr,
            "ssim_delta": r.ssim - baseline.ssim,
            "lpips_delta": r.lpips - baseline.lpips,
            "fps_delta_pct": (r.inference_fps / baseline.inference_fps - 1) * 100 if baseline.inference_fps > 0 else 0,
            "train_time_delta_pct": (r.train_time_hours / baseline.train_time_hours - 1) * 100 if baseline.train_time_hours > 0 else 0,
            "gpu_mem_delta_pct": (r.peak_gpu_memory_gb / baseline.peak_gpu_memory_gb - 1) * 100 if baseline.peak_gpu_memory_gb > 0 else 0,
        }
    
    return comparison


def region_based_analysis(
    per_view_results: Dict[str, Dict[str, float]],
    region_labels: Dict[str, str]  # view_id -> "textured" | "weak_texture" | "reflective"
) -> Dict[str, Dict[str, float]]:
    """
    Perform region-based analysis of PSNR improvements.
    
    Groups views by scene characteristics to identify where
    improvements are most effective.
    """
    region_metrics = {}
    for region_name in set(region_labels.values()):
        region_views = [vid for vid, r in region_labels.items() if r == region_name]
        if not region_views:
            continue
        
        region_psnrs = [per_view_results[v]["psnr"] for v in region_views if v in per_view_results]
        if region_psnrs:
            region_metrics[region_name] = {
                "mean_psnr": np.mean(region_psnrs),
                "std_psnr": np.std(region_psnrs),
                "n_views": len(region_psnrs),
            }
    
    return region_metrics


def validate_experiment_fairness(configs: List[ExperimentConfig]) -> List[str]:
    """
    Validate that all experiments follow the fairness requirements
    from the assignment rubric:
    - Same hardware
    - Same hyperparameters (except the improvement under test)
    - Same scenes
    - Same random seed
    """
    issues = []
    
    baseline = configs[0]
    for cfg in configs[1:]:
        if cfg.iterations != baseline.iterations:
            issues.append(f"{cfg.name}: iterations mismatch ({cfg.iterations} vs {baseline.iterations})")
        if cfg.n_offsets != baseline.n_offsets:
            issues.append(f"{cfg.name}: n_offsets mismatch")
        if cfg.feat_dim != baseline.feat_dim:
            issues.append(f"{cfg.name}: feat_dim mismatch")
        if cfg.seed != baseline.seed:
            issues.append(f"{cfg.name}: seed mismatch")
    
    return issues


def generate_latex_table(comparison: Dict) -> str:
    """
    Generate a LaTeX table from comparison results for the academic report.
    """
    lines = [
        r"\begin{table}[t]",
        r"\centering",
        r"\caption{Quantitative comparison of proposed improvements against baseline.}",
        r"\label{tab:comparison}",
        r"\begin{tabular}{lcccr}",
        r"\hline",
        r"Method & PSNR$\uparrow$ & SSIM$\uparrow$ & LPIPS$\downarrow$ & FPS$\uparrow$ \\",
        r"\hline",
    ]
    
    base = comparison["baseline"]
    lines.append(f"Baseline & {base['psnr']:.2f} & {base['ssim']:.3f} & {base['lpips']:.3f} & {base['fps']:.1f} \\\\")
    
    for name, delta in comparison["deltas"].items():
        clean_name = name.replace("_", r"\_")
        lines.append(
            f"{clean_name} & "
            f"{base['psnr'] + delta['psnr_delta']:.2f} \\tiny{{({delta['psnr_delta']:+.2f})}} & "
            f"{base['ssim'] + delta['ssim_delta']:.3f} & "
            f"{base['lpips'] + delta['lpips_delta']:.3f} & "
            f"{base['fps'] * (1 + delta['fps_delta_pct']/100):.1f} \\tiny{{({delta['fps_delta_pct']:+.0f}\%)}} \\\\"
        )
    
    lines.extend([
        r"\hline",
        r"\end{tabular}",
        r"\end{table}",
    ])
    
    return "\n".join(lines)


# ============================================================================
# Metric Computation Helpers
# ============================================================================

def compute_psnr(rendered: np.ndarray, gt: np.ndarray) -> float:
    """Compute PSNR between rendered and ground truth images."""
    mse = ((rendered - gt) ** 2).mean()
    if mse == 0:
        return float('inf')
    return 20 * np.log10(1.0 / np.sqrt(mse))


def compute_per_region_metrics(
    rendered_path: str,
    gt_path: str,
    region_mask_path: Optional[str] = None
) -> Dict[str, float]:
    """
    Compute metrics with optional per-region breakdown.
    
    If region_mask_path is provided, separates metrics for
    textured vs. texture-less regions.
    """
    # Placeholder for metric computation
    # In practice, load rendered images, ground truth, compute PSNR/SSIM/LPIPS
    pass
