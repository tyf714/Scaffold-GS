# Scaffold-GS Improvement Project -- SLAM 2026 Final

**Author**: Yifan Tang / 2335053620
**Institution**: University of Shanghai for Science and Technology
**Department**: School of Mechanical Engineering, Robotics Engineering
**GitHub**: github.com/tyf714/Scaffold-GS (branch: improvement/eaad-casef)

---

## Two Independent Improvements

This project identifies two methodological limitations in Scaffold-GS [1] and proposes targeted solutions:

| # | Defect (Report Section IV) | Solution (Section V) | Core Mechanism |
|---|---|---|---|
| L1 | Authors claim gradient growing "partially mitigates" SfM holes, but source code proves the mitigation is structurally incapable of activating (line 683 deadlock) | **EAAD**: Error-Guided Anchor Densification | Pixel-space rendering error replaces gradient-based signal, breaking the deadlock |
| L2 | Four independent MLPs redundantly process identical input (lines 106-128), 32-dim bottleneck | **CASEF**: Cross-Attention Shared Encoder | Shared encoder (36->128) + cross-attribute attention + lightweight heads |

See report Section IV for evidence and Section V for design.

---

## Quick Start

### 1. Fork and Clone
```bash
git clone --recursive https://github.com/tyf714/Scaffold-GS.git
cd Scaffold-GS
git checkout improvement/eaad-casef
```

### 2. Environment
```bash
conda create -n scaffold_gs python=3.7.13
conda activate scaffold_gs
pip install torch==1.12.1+cu116 torchvision==0.13.1+cu116 --extra-index-url https://download.pytorch.org/whl/cu116
pip install plyfile tqdm einops lpips torch_scatter
pip install submodules/diff-gaussian-rasterization submodules/simple-knn
```

Requirements: Python 3.7, PyTorch 1.12.1, CUDA 11.6, NVIDIA GPU >= 8GB VRAM.

### 3. Run Baseline (C0)
```bash
python train.py -s data/nerf_synthetic/lego -m output/lego_baseline \
    --eval --seed 42 --feat_dim 32 --n_offsets 10 --voxel_size 0.001 \
    --update_depth 3 --update_init_factor 16 --update_hierachy_factor 4 \
    --iterations 30000 --test_iterations 30000 --save_iterations 30000
```

### 4. Run EAAD (C1)
```bash
python train.py -s data/nerf_synthetic/lego -m output/lego_eaad \
    --eval --seed 42 --use_eaad --error_threshold 0.1 --densify_interval 500 \
    --start_densify 2000 --end_densify 12000 --max_new_anchors 500 \
    --feat_dim 32 --n_offsets 10 --voxel_size 0.001 \
    --iterations 30000
```

### 5. Run CASEF (C2)
```bash
python train.py -s data/nerf_synthetic/lego -m output/lego_casef \
    --eval --seed 42 --use_casef --d_model 128 --n_heads 4 \
    --feat_dim 32 --n_offsets 10 --voxel_size 0.001 \
    --iterations 30000
```

### 6. Run Combined (C3) / Ablations (C4, C5)
Combine `--use_eaad --use_casef` for C3. For C4: add `--feature_init_mode zero`. For C5: add `--no_cross_attn`.

---

## Code Changes (improvements/)

- **eaad_densifier.py**: ErrorGuidedAnchorDensifier class + integration instructions for gaussian_model.py and train.py
- **casef_unified_decoder.py**: SharedFeatureEncoder + CrossAttributeAttention + LightweightHeads + UnifiedGaussianDecoder, replacing gaussian_model.py lines 98-128

## Experiment Logs (logs/)

- training_baseline_lego_7k.log: Colab T4 baseline run at 7K iterations
- colab_execution.log: Colab environment
- environment.txt: Local environment

## Metrics (data/metrics/)

- results.json: Per-configuration aggregated metrics
- per_view_metrics.csv: Per-view PSNR/SSIM with region labels

## References

[1] T. Lu et al., "Scaffold-GS: Structured 3D Gaussians for View-Adaptive Rendering," CVPR 2024 (Highlight).
[2] B. Kerbl et al., "3D Gaussian Splatting for Real-Time Radiance Field Rendering," SIGGRAPH 2023.
